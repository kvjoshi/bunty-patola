 $(function() {
        $(".dial").knob();
          $('.dial').trigger(
        'configure',
        {
            "fgColor":"#0084ff"
        }
    );
    });


