/* 
 Form wizard
 */
$(function () {
    $('.wizard-example').wizard({
        buttonLabels: {
            next: 'Next',
            back: 'Back',
            finish: 'Save Changes'
        }
    });
});

