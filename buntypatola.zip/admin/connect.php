<?php
$servername ="localhost";
$username = "root";
$password = "";
$dbname = "buntypatola";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
?>
