<?php
$servername = "localhost";
$username = "u996660230_kv";
$password = "Shhiambatman@11";
$dbname = "u996660230_opal ";

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
?>
